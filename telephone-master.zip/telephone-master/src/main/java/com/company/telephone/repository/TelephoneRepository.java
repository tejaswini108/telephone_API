package com.company.telephone.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.company.telephone.entity.TelephoneEntity;

public interface TelephoneRepository extends CrudRepository<TelephoneEntity, Long> {
	Page<TelephoneEntity> findByNumber(String number, Pageable pageable);
}
