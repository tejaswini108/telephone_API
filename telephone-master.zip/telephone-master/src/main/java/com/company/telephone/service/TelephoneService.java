package com.company.telephone.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.company.telephone.entity.TelephoneEntity;
import com.company.telephone.repository.TelephoneRepository;

@Service
public class TelephoneService {

	@Autowired
	private TelephoneRepository repo;
	
	public Long addPermutations(String telephoneNumber) {
		System.out.println(telephoneNumber);
		List<String> permutations = letterCombinations(telephoneNumber);
		List<TelephoneEntity> entities = permutations.stream()
		.filter(Objects::nonNull)
		.map(x -> new TelephoneEntity(telephoneNumber, x))
		.collect(Collectors.toList());
		
		repo.saveAll(entities);
		return repo.count();
	}
	
	public Page<String> getNumbers( @NotBlank String telephoneNumber, Pageable pageable) {
		return repo.findByNumber(telephoneNumber, pageable).map(x -> x.getPermutationNumber());
	}
	
	public List<String> letterCombinations(String digits) {
	    Map<Character, String> map = new HashMap<>();
	    map.put('0', "0");
	    map.put('1', "1");
	    map.put('2', "abc");
	    map.put('3', "def");
	    map.put('4', "ghi");
	    map.put('5', "jkl");
	    map.put('6', "mno");
	    map.put('7', "pqrs");
	    map.put('8', "tuv");
	    map.put('9', "wxyz");
	 
	    List<String> l = new ArrayList<>();
	    if (digits == null || digits.length() == 0) {
	        return l;
	    }
	 
	    l.add("");
	 
	    for (int i = 0; i < digits.length(); i++) {
	        ArrayList<String> temp = new ArrayList<>();
	        String option = map.get(digits.charAt(i));
	 
	        for (int j = 0; j < l.size(); j++) {
	            for (int p = 0; p < option.length(); p++) {
	                temp.add(new StringBuilder(l.get(j)).append(option.charAt(p)).toString());
	            }
	        }
	 
	        l.clear();
	        l.addAll(temp);
	    }
	 
	    return l;
	}

	

}
