package com.company.telephone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelephoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelephoneApplication.class, args);
	}

}
