package com.company.telephone.controller;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.telephone.service.TelephoneService;

@RestController
public class TelephoneController {
	
	@Autowired
	private TelephoneService service;
	
	@PostMapping("/telephone-number")
	@Validated
	public String addNumberPermutations(@RequestBody 
	@Pattern(regexp = "^(\\+\\d{1,2}\\s?)?1?\\-?\\.?\\s?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$")
	@NotBlank final String telephoneNumber) {
		return "Added all total combinations : " + service.addPermutations(telephoneNumber) + " to H2 database";
	}
	
	@GetMapping("/telephone-number/{number}")
	@Validated
	public Page<String> getAllNumbers(@PathVariable(name = "number") @Pattern(regexp = "^(\\+\\d{1,2}\\s?)?1?\\-?\\.?\\s?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$")
	@NotBlank final String telephoneNumber, int page, int size){
		return service.getNumbers(telephoneNumber, PageRequest.of(page, size));
	}
 
}
