package com.company.telephone.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TELEPHONE_NUMBER_PERMUTATION")
public class TelephoneEntity {

	public TelephoneEntity() {
		super();
	}

	@Id
    @GeneratedValue
    @Column(name = "Id", nullable = false)
    private Long id;
 
    @Column(name = "Number", nullable = false)
    private String number;
    
    @Column(name = "PermutationNumber", nullable = false)
    private String permutationNumber;
    
	public TelephoneEntity(String number, String permutationNumber) {
		this.number = number;
		this.permutationNumber = permutationNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getPermutationNumber() {
		return permutationNumber;
	}

	public void setPermutationNumber(String permutationNumber) {
		this.permutationNumber = permutationNumber;
	}
}

